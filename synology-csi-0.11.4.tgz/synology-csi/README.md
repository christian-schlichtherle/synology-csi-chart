# Synology CSI Chart for Kubernetes

This is a
[Helm](https://helm.sh) chart for installing the
[Synology CSI Driver](https://github.com/SynologyOpenSource/synology-csi) in a
[Kubernetes](https://kubernetes.io) cluster.
It has been forked from the original resource manifests bundled with the Synology CSI Driver to resolve some
issues and to benefit from the advanced resource management features available with Helm.

## Features

+ Customizable images, image pull policies and image tags for all CSI containers.
+ Customizable parameters for `StorageClass` and `VolumeSnapshotClass` resources.
+ Customizable `affinity`, `nodeSelector` and `tolerations` properties for the `StatefulSet` and `DaemonSet` workloads.
+ Automatic installation of storage classes for the iSCSI, NFS and SMB protocols, each with `reclaimPolicy=Delete` and
  `reclaimPolicy=Retain` - plus commented examples for NVMe/TCP, which requires a PAS7700 and driver v1.3.0 or later.
+ Automatic installation of a CSI Snapshotter if the `VolumeSnapshotClass` CRD is installed in your cluster.

## Prerequisites

+ [Helm](https://helm.sh) must be installed to use this chart.
  Please refer to Helm's [documentation](https://helm.sh/docs) to get started.
+ A Synology Diskstation with the SAN Manager package installed (the package name was changed in DSM 7).
+ A cluster with [Kubernetes](https://kubernetes.io) version 1.20 or later.
+ `iscsiadm` installed on every cluster node if and only if you want to mount iSCSI volumes.
+ `kubectl` installed on your localhost and configured to connect to the cluster.
+ Optional: [CSI Snapshotter](https://github.com/kubernetes-csi/external-snapshotter) installed in the cluster.

## Usage

Once Helm has been set up correctly, add the repo as follows:

    helm repo add synology-csi-chart https://christian-schlichtherle.github.io/synology-csi-chart

If you had already added this repo earlier, run `helm repo update` to retrieve the latest versions of the packages.
You can then run `helm search repo synology-csi-chart` to see the charts.

To install the chart:

    helm install <release-name> synology-csi-chart/synology-csi

To uninstall the chart:

    helm delete <release-name>

### Customizing the Configuration

As usual with Helm, you can override the values in the file [`values.yaml`](values.yaml) to suit your requirements - see
[Customizing the Chart Before Installing](https://helm.sh/docs/intro/using_helm/#customizing-the-chart-before-installing).
In particular, override the section `clientInfoSecret.clients` to match the connection parameters and credentials for
accessing your Synology Diskstation.

You can also use an existing secret (specify using the key `clientInfoSecret.name`) that contains a `clients`
dictionary under `client-info.yaml` key:

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: <release-name>-client-info
stringData:
  client-info.yaml: |
    clients:
    - host: 192.168.1.1
      https: false
      password: changeme
      port: 5000
      username: changeme
    - host: 192.168.1.1
      https: true
      password: changeme
      port: 5001
      username: changeme
```

It's a good practice to create a dedicated user for accessing the Diskstation Manager (DSM) application.
Your user needs to be a member of the `administrators` group and have permission to access the `DSM` application.
You can safely reject all other permissions.

### Verifying the TLS Certificate of the Diskstation

> [!IMPORTANT]
> Driver version v1.3.1 changed the HTTPS behavior:
> up to v1.3.0 the driver silently skipped certificate verification, whereas since v1.3.1 it verifies the certificate of
> the Diskstation.
> If you use `https: true` with a self-signed DSM certificate, then you have to configure one of the options below -
> otherwise the driver can no longer log in to DSM.

Each entry of `clientInfoSecret.clients` accepts these optional keys if `https: true` (driver v1.3.1 or later):

| Key                  | Description                                                                                                                                                                   |
|----------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `tlsCACert`          | PEM-encoded CA certificate for verifying the DSM endpoint. The system CA pool is always included, so certificates signed by a public CA (e.g. Let's Encrypt) can be left out.  |
| `tlsServerName`      | The server name to verify the certificate against. Required if `host` is an IP address but the certificate only has DNS names - the default for DSM self-signed certificates.  |
| `insecureSkipVerify` | Set to `true` to disable certificate verification entirely. Not recommended - use `tlsCACert` instead. The driver logs a warning on every connection if enabled.               |

For a Diskstation with a self-signed certificate which is accessed by IP address, a typical configuration looks like
this:

```yaml
clientInfoSecret:
  clients:
    - host: 192.168.1.1
      https: true
      password: changeme
      port: 5001
      username: changeme
      tlsCACert: |
        -----BEGIN CERTIFICATE-----
        ...
        -----END CERTIFICATE-----
      tlsServerName: synology # the host name in the certificate's CN or SAN field
```

### Choosing the File System for iSCSI Volumes

> [!WARNING]
> Driver version v1.4.0 dropped support for `fsType: btrfs`:
> the driver image is now based on Red Hat UBI 9, which does not ship `btrfs-progs`, so the driver can no longer run
> `mkfs.btrfs` inside the container.
> If you have iSCSI `PersistentVolume`s which were formatted as Btrfs, then migrate them to `ext4` or `xfs` before
> upgrading, or stay on driver v1.3.1 by pinning `images.plugin.tag`.

The `fsType` parameter of a storage class only applies to the iSCSI protocol and accepts `ext4` (the default) or `xfs`.
This is about the file system *inside* the LUN, not about the volume on the Diskstation:
Btrfs volumes and thin-provisioned Btrfs LUNs on DSM are unaffected because DSM formats these itself - the storage class
parameter `enableSpaceReclamation` keeps working as before.

### Running the Driver as a Non-Root User

Since v1.4.0 the driver image declares `USER 1000` in order to satisfy the *RunAsNonRoot* check of the Red Hat container
certification.
The controller and snapshotter workloads run as this user, whereas the node `DaemonSet` overrides it with
`securityContext.runAsUser: 0`, because mounting, formatting and the `chroot` into the host all require root -
`privileged: true` alone does not change the user a container runs as.
This chart configures all of that for you; it's only relevant if you write your own manifests.

## Local Development

### Installing the Chart from Source

Clone this repository and change into its directory.
You can run `helm install ...` as usual.
However, for convenience it's recommended to use the provided `Makefile` and run:

    $ make up

... or just:

    $ make

The `diff`, `template` and `up`/`upgrade` targets pass `--values .values.yaml`, so create that file with your local
overrides first - otherwise `make` fails with `open .values.yaml: no such file or directory`.

### Testing the Chart

The Synology CSI Driver is now ready for testing.

#### Automated Testing

    $ make test

For each storage class which has the `test` property set to `true`, this will create a `PersistentVolumeClaim` (PVC) and
a pod which mounts the associated `PersistentVolume` (PV).
The pod will run a performance test for about a minute using fio.
You can check the logs to read the performance test results.

### Troubleshooting

First, make sure to run the automated test.
This may hang if the PVC cannot be bound for some reason, for example if you forgot to edit the credentials for
accessing the Diskstation Manager application.
In other cases it may fail with an error message but then the resources do not get deleted so that you can troubleshoot
the issue.

For example, let's assume this chart has been installed using `make` and thus its namespace is `synology-csi`:

```
$ NAMESPACE=synology-csi
```

Now let's look at the pod for the test job:

```
$ kubectl describe pods -n $NAMESPACE -l helm.sh/template=test_pod.yaml
[...]
Volumes:
  test:
    Type:       PersistentVolumeClaim (a reference to a PersistentVolumeClaim in the same namespace)
    ClaimName:  synology-csi-iscsi-delete-test
    ReadOnly:   false
[...]
Events:
  Type     Reason            Age                 From               Message
  ----     ------            ----                ----               -------
  Warning  FailedScheduling  3m6s                default-scheduler  0/4 nodes are available: 4 pod has unbound immediate PersistentVolumeClaims.
  Warning  FailedScheduling  61s (x1 over 2m1s)  default-scheduler  0/4 nodes are available: 4 pod has unbound immediate PersistentVolumeClaims.
```

The test PVC isn't bound.
Let's examine why:

```
$ kubectl describe pvc -n $NAMESPACE -l helm.sh/template=test_persistentvolumeclaim.yaml
[...]
Events:
  Type     Reason                Age                     From                                                                  Message
  ----     ------                ----                    ----                                                                  -------
  Normal   Provisioning          4m2s (x9 over 8m17s)    csi.san.synology.com_kolossus-3_c3a0b188-fa91-409b-a4d1-0316d5ffbbd6  External provisioner is provisioning volume for claim "synology-csi/synology-csi-iscsi-delete-test"
  Warning  ProvisioningFailed    4m2s (x9 over 8m17s)    csi.san.synology.com_kolossus-3_c3a0b188-fa91-409b-a4d1-0316d5ffbbd6  failed to provision volume with StorageClass "synology-csi-iscsi-delete": rpc error: code = Internal desc = Couldn't find any host available to create Volume
  Normal   ExternalProvisioning  2m25s (x26 over 8m17s)  persistentvolume-controller                                           waiting for a volume to be created, either by external provisioner "csi.san.synology.com" or manually created by system administrator
```

The events mention a provisioner which is running in a container named `csi-plugin` in a controller pod which has been
deployed as part of this chart.
Let's examine the logs of this plugin container:

```
$ kubectl logs -n $NAMESPACE -l helm.sh/template=controller_statefulset.yaml -c csi-plugin
[...]
2022-01-25T08:19:57Z [INFO] [driver/utils.go:104] GRPC call: /csi.v1.Controller/CreateVolume
2022-01-25T08:19:57Z [INFO] [driver/utils.go:105] GRPC request: {"capacity_range":{"required_bytes":1073741824},"name":"pvc-a3d7962b-0ab5-4184-b545-a44cc424aaf1","parameters":{"fsType":"ext4"},"volume_capabilities":[{"AccessType":{"Mount":{"fs_type":"ext4"}},"access_mode":{"mode":1}}]}
2022-01-25T08:19:57Z [ERROR] [driver/utils.go:108] GRPC error: rpc error: code = Internal desc = Couldn't find any host available to create Volume
```

After all, we found out that the plugin isn't able to connect to the Diskstation.
This is because I didn't edit the `clientInfoSecret.clients` dictionary in the `values.yaml` file.
After fixing that the test passes as expected.

### Uninstalling the Chart

    $ make down

---

**SUCCESS - enjoy!**
